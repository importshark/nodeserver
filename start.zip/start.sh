@echo off
cd content
node boot.js
pause